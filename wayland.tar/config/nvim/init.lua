vim.g.mapleader = ' '

require('plugins')
require('options')
require('autocommands')
require('keybindings')
