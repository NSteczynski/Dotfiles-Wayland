require'colorizer'.setup()
