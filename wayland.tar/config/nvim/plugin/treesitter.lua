require'nvim-treesitter.configs'.setup { highlight = { enable = true } }
