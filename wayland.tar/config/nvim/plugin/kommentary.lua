require('kommentary.config').use_extended_mappings()
